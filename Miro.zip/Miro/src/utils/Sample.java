
package utils;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Sample{
	static WebDriver driver;
@Test(dataProvider="testdata")
public void demoClass(String username, String password) throws InterruptedException {
//public void demoClass(String name, String workemai, String password) throws InterruptedException {
	
	int altnum = new Random().nextInt(50) + 1000;
	System.out.println(altnum);
System.setProperty("webdriver.chrome.driver", "C:\\Users\\Home\\Desktop\\Chrome Driver\\chromedriver.exe");

driver = new ChromeDriver();
driver.get("https://miro.com/signup/");

driver.findElement(By.id("name")).sendKeys(username);
driver.findElement(By.id("email")).sendKeys("auto"+altnum+"@gmail.com");
driver.findElement(By.id("password")).sendKeys(password);
driver.findElement(By.xpath("//div[@class='signup__checkbox-wrap']//label[@class='mr-checkbox-1__check ']")).click();
//driver.findElement(By.cssSelector("h1.signup__title-form")).click();
//driver.findElement(By.cssSelector("button.signup__submit")).click();

WebElement element = driver.findElement(By.cssSelector("button.signup__submit"));
JavascriptExecutor executor = (JavascriptExecutor)driver;
executor.executeScript("arguments[0].click();", element);
Thread.sleep(5000);

String checkText = driver.findElement(By.cssSelector("h1.signup__title-form")).getText();

System.out.println("=======================");
String str1 = checkText.toLowerCase();
System.out.println(str1);
String str2 = "Check your email".toLowerCase();
System.out.println(str2);
System.out.println("=======================");

//if (str1==str2) {
if (str1.equals(str2)) {
	System.out.println("Check your email is diplayed.");
}else {
	System.out.println("Miro account is not created");
}
//Assert.assertTrue(driver.getTitle().matches("BrowserStack Login | Sign Into The Best Mobile & Browser Testing Tool"), "Invalid credentials");
//System.out.println("Login successful");

}

@AfterMethod
void ProgramTermination() {
driver.quit();
} 


@DataProvider(name="testdata")
public Object[][] testDataExample(){
ExcelUtils configuration = new ExcelUtils("C:\\Users\\Home\\Desktop\\Selenium_Java_WS\\Miro\\TestData\\testData.xlsx");
//	ExcelUtils configuration = new ExcelUtils("user.dir"+"\\TestData\testData.xlsx");
//	ExcelUtils configuration = new ExcelUtils(".\testData.xlsx");
int rows = configuration.getRowCount(0);
System.out.println(rows);
Object[][] signin_credentials = new Object[rows][2];

for(int i=0;i<rows;i++)
{
signin_credentials[i][0] = configuration.getData(0, i, 0);
signin_credentials[i][1] = configuration.getData(0, i, 1);
//signin_credentials[i][2] = configuration.getData(0, i, 2);
//signin_credentials[i][1] = configuration.getData(0, i, 1);
}
return signin_credentials;
}
}