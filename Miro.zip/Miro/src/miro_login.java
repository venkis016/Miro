

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.concurrent.TimeUnit;




///import net.jodah.failsafe.internal.util.Assert;

public class miro_login {

	public static void main(String[] args) {
		 //TODO Auto-generated method stub
	
	//public void mirologin() {
		
		
//		user.dir
		File src = new File("E:\\Selenium_Java\\Selenium-Soft 8_11_16\\Selenium_Java_WS\\Miro\\TestData\\testData.xlsx");
		try {
			FileInputStream fio = new FileInputStream(src);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\Selenium_Java\\Selenium-Soft 8_11_16\\Drivers_C_FF_IE\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();	
		driver.manage().window().maximize();
		driver.get("https://miro.com/signup/");
		
		WebElement username = driver.findElement(By.id("name"));
		WebElement email = driver.findElement(By.id("email"));
		WebElement password = driver.findElement(By.id("password"));
		WebElement termsandconditions = driver.findElement(By.xpath("//div[@class='signup__checkbox-wrap']//label[@class='mr-checkbox-1__check ']"));
//		WebElement getbutton = driver.findElement(By.cssSelector("button.signup__submit"));
		WebElement getbutton = driver.findElement(By.cssSelector("h1.signup__title-form"));
		WebElement cookiestbutton = driver.findElement(By.xpath("//button[@id='onetrust-accept-btn-handler']"));
		
		username.sendKeys("vb");
		email.sendKeys("bh@gmail.com");
		password.sendKeys("#siSl1001");
		cookiestbutton.click();
		
		
		termsandconditions.click();
//		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		String buttontest = getbutton.getText();
		System.out.println(buttontest);
		getbutton.click();
		
		String actualstrings = "Check your email";
		WebElement expectestrins = driver.findElement(By.cssSelector("h1.signup__title-form"));
		//System.out.println(0)
//		Assert.assertEquals(expectestrins,actualstrings);
//		Assert.		
		
	}

}
